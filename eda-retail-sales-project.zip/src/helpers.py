import pandas as pd
import numpy as np

def parse_dates(df, col):
    df[col] = pd.to_datetime(df[col], errors='coerce')
    return df

def basic_clean(df):
    df = df.drop_duplicates()
    essential = [c for c in ['order_id','order_date','customer_id','product_id','quantity','unit_price','revenue'] if c in df.columns]
    if essential:
        df = df.dropna(subset=essential)
    return df

def describe_numeric(df):
    num = df.select_dtypes(include=['number'])
    return num.describe().T

def monthly_sales(df, date_col='order_date', value_col='revenue'):
    m = (df
         .set_index(pd.to_datetime(df[date_col]))
         .resample('M')[value_col]
         .sum()
         .to_frame('monthly_revenue')
         .reset_index())
    m['month'] = m[date_col].dt.to_period('M').astype(str)
    return m[['month','monthly_revenue']]