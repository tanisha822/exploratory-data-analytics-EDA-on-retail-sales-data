# Retail Sales EDA Report

**Date:** 2025-09-04

## 1. Objective
Summarize the purpose and scope of the analysis.

## 2. Data Sources
- Dataset 1: Retail sales transactions (orders, customers, products).
- Dataset 2: Product catalog (categories, base prices).

## 3. Data Cleaning
- Duplicates removed
- Missing values handled
- Date parsing
- Basic sanity checks

## 4. Descriptive Statistics
Insert key metrics (mean, median, std) for revenue, unit_price, quantity, etc.

## 5. Time Series Analysis
- Monthly revenue trend
- Seasonality observations
- Notable peaks/dips

## 6. Customer Analysis
- Top customers by revenue
- Frequency and recency highlights
- Demographic insights

## 7. Product & Category Analysis
- Top categories/products
- Price vs. quantity observations
- Cross-category comparisons

## 8. Heatmap (Category x Month)
- Explain any seasonal category patterns

## 9. Recommendations
- Pricing strategy
- Promotions & discounting
- Inventory planning
- Customer segmentation & retention tactics

## 10. Next Steps
- Forecasting (ARIMA/Prophet)
- A/B tests for promotions
- Data enrichment (marketing, returns)